﻿using System;
using CoreBluetooth;
using CoreFoundation;
using UIKit;
using System.Text;
using Foundation;

namespace TME
{
    public partial class FirstViewController : UIViewController
    {
        MySimpleCBCentralManagerDelegate myDel;
        // CBCharacteristic Characteristic;
        private DiscoveredItemsTableSource tableSource;
        private CBCentralManager myMgr;
        private CBService service;
        private string str;

        private string StrTemp;
        private string Str1;
        // public string st;
        //  private string uuid;
        //  private string UUID_TX = "FEFB";//.ToLower();
        private string TIO_UART_RX_UUID = "00000001-0000-1000-8000-008025000000";
        private string TIO_UART_TX_UUID = "00000002-0000-1000-8000-008025000000";
        private string TIO_UART_RX_CREDITS_UUID = "00000003-0000-1000-8000-008025000000";
        private string TIO_UART_TX_CREDITS_UUID = "00000004-0000-1000-8000-008025000000";
        public static CBCharacteristic UartRxCreditsCharacteristic;
        public static CBCharacteristic UartRxCharacteristic;
        public static CBCharacteristic UartTxCharacteristic;
        public static CBCharacteristic UartTxCreditsCharacteristic;
        ////private string UUID_TX = "ADABFB00-6E7D-4601-BDA2-BFFAA68956BA".ToLower();
        public FirstViewController(IntPtr handle) : base(handle)
        {
            // MySimpleCBCentralManagerDelegate mySimpleCBCentralManagerDelegate = new MySimpleCBCentralManagerDelegate();
        }
        // private MySimpleCBCentralManagerDelegate MySimpleCBCentralManagerDelegate;

        [Foundation.Export("viewDidAppear:")]

        public virtual void viewDidAppear(bool animated)
        {
            UIViewController uIViewController = new UIViewController();
            // private MySimpleCBCentralManagerDelegate MySimpleCBCentralManagerDelegate;
            // CBCentralManagerDelegate cBCentralManagerDelegate
            // MySimpleCBCentralManagerDelegate mySimpleCBCentralManagerDelegate = new MySimpleCBCentralManagerDelegate();
            // FirstViewController firstViewController = new FirstViewController();
        }
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            tableSource = new DiscoveredItemsTableSource(this);

            discoverTable.Source = tableSource;
        }

        private void PeripheralManager_DidReceiveData(object sender, DidReceiveDataEventArgs e)
        {
            Str1 = e.Data;
            if (e.Recdat == 3)
            {
                // set the log counter
              //  Serialno();
            }

            if (e.Recdat == 5)
            {
               // Instname();
            }
        }
        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }

        partial void UIButton8_TouchUpInside(UIButton sender)
        {
            tableSource.TableItems.Clear();
            discoverTable.ReloadData();
            myDel = new MySimpleCBCentralManagerDelegate(this);
            myMgr = new CBCentralManager(myDel, DispatchQueue.CurrentQueue);
            name.Text = "";
            name2.Text = "";
        }



/*

        internal void Connect(CBPeripheral peripheral)
        {
            peripheral.DiscoveredService += (sender, e) =>
            {
                if (peripheral.Services == null) { return; }
                foreach (var s in peripheral.Services)
                {
                    if (s.UUID.ToString().Contains("fefb"))
                    {
                        service = s;
                        peripheral.DiscoverCharacteristics(service);
                    };
                }
            };

            peripheral.DiscoveredCharacteristic += (sender, e) =>
            {
                //  peripheral.DiscoveredCharacteristic += (sender, e) =>
                // {
                foreach (var c in service.Characteristics)
                {
                    if (c.UUID.ToString() == (TIO_UART_RX_UUID))
                    {
                        UartRxCharacteristic = c;
                    }
                }
            };
            peripheral.DiscoveredCharacteristic += (sender, e) =>
            {
                foreach (var c in service.Characteristics)
                {

                    if (c.UUID.ToString() == (TIO_UART_RX_CREDITS_UUID)) //|| (c.UUID.ToString() == TIO_UART_TX_CREDITS_UUID))

                    {
                        UartRxCreditsCharacteristic = c;
                    }
                }
            };



            peripheral.DiscoveredCharacteristic += (sender, e) =>

            {

                foreach (var c in service.Characteristics)
                {

                    if (c.UUID.ToString() == (TIO_UART_TX_CREDITS_UUID))
                    {
                        UartTxCreditsCharacteristic = c;

                        if (Global.PeripheralManager != null)
                        {
                            Global.PeripheralManager.Dispose();
                        }
                        peripheral.SetNotifyValue(true, c);

                        //var i = 1;
                        // for (int i = 0; i <  3; i++)
                        // {
                        Global.PeripheralManager = new PeripheralManager(peripheral, c);
                        Global.PeripheralManager.DidReceiveData += PeripheralManager_DidReceiveData;

                        // }
                        //  peripheral.SetNotifyValue(true, c);
                        //  Global.PeripheralManager = new PeripheralManager(peripheral, c);
                        //  Global.PeripheralManager.DidReceiveData += PeripheralManager_DidReceiveData;
                    }
                }
            };

            peripheral.DiscoveredCharacteristic += (sender, e) =>
            {
                foreach (var c in service.Characteristics)
                {
                    if (c.UUID.ToString() == (TIO_UART_TX_UUID)) // == UUID_TX)
                                                                 //   UartTxCharacteristic = c; 
                    {
                        peripheral.SetNotifyValue(true, c);

                        //  peripheral.WriteValue(NSData.FromArray(ToBinary("\r\nU\r\n")), c, CBCharacteristicWriteType.WithResponse);

                        if (Global.PeripheralManager != null)
                        {
                            //Global.PeripheralManager.Dispose();
                        }

                        Global.PeripheralManager = new PeripheralManager(peripheral, c);
                        Global.PeripheralManager.DidReceiveData += PeripheralManager_DidReceiveData;
                        StrTemp = "";
                        Str1 = "";
                        var recdat = 3;


                        Global.PeripheralManager.Write(":F\r\n", recdat);

                        //  name.Text = str;
                    };
                }

            };


            myMgr.ConnectPeripheral(peripheral);

        }
*/
        byte[] ToBinary(string s)
        {
            return Encoding.ASCII.GetBytes(s);
        }

        internal void Discovered(CBPeripheral peripheral, string dataServiceUUID)
        {
            {
                tableSource.TableItems.Add(new DiscoverItem(peripheral, dataServiceUUID));
                discoverTable.ReloadData();
            }
        }

        internal void SendFirstData(CBPeripheral peripheral)
        {
            peripheral.DiscoverServices();
        }

      /*  partial void UIButton21_TouchUpInside(UIButton sender)
        {
            {
                // peripheral = (this.Peripheral);
                //
                // peripheral = Discovered(peripheral, dataServiceUUID);
                if (Global.PeripheralManager != null && Global.PeripheralManager.Peripheral != null)
                {

                    //   name.Text = "disconnect function";
                    if (Global.PeripheralManager.Peripheral.State != CBPeripheralState.Disconnected)
                    {
                        Disconnect();
                        // name.Text = "here";
                    }

                }
            }
        }
        internal void Disconnect()
        {

            {


                //str = "\r\nD\r\n";
                // FirstViewController str = new FirstViewController();

                // Global.PeripheralManager.Write(str);

                // peripheral.WriteValue(NSData.FromArray(ToBinary("\r\nD\r\n")), c, CBCharacteristicWriteType.WithResponse);
                myMgr.CancelPeripheralConnection(Global.PeripheralManager.Peripheral);

                Global.PeripheralManager.DidReceiveData -= PeripheralManager_DidReceiveData;
                Global.PeripheralManager.Dispose();
            }
        }
      */
        // partial void Settimedate_TouchUpInside(UIButton sender)
        // {      
        //    Settime();
        // }
        /*  internal void Settime()
          {
              str = (":C") ;
              Global.PeripheralManager.Write(str);
              str = DateTime.Now.ToString();

              Global.PeripheralManager.Write(str);
              str = ("\r\n");
              Global.PeripheralManager.Write(str);

          }
          internal void Serialno()

          {
              StrTemp = StrTemp + Str1;
              if (StrTemp.Length > 5)
              {
                  name.Text = StrTemp;
                  //write cell
                  var recdat = 5;
                  StrTemp = "";
                  Str1 = "";
                  str = (":U\r\n");
                  Global.PeripheralManager.Write(str, recdat);

              }
          }
          internal void Instname()
          {
              StrTemp = StrTemp + Str1;
              name2.Text = StrTemp;
              //write cell
          }
      }*/
    }
}