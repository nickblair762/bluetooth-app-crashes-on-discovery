﻿namespace TME
{
    public class DidReceiveDataEventArgs
    {
        public int? Recdat { get; private set; }
        public string Data { get; private set; }

        public DidReceiveDataEventArgs(int? recdat, string data)
        {
            this.Recdat = recdat;
            this.Data = data;
        }
    }
}