namespace TME
{
    public static class Global
    {
        public static PeripheralManager PeripheralManager { get; set; }
    }
}