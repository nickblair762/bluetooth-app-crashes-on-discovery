﻿using CoreBluetooth;

namespace TME
{
    public  class DiscoverItem
    {
        private string dataServiceUUID;

        public DiscoverItem(CBPeripheral peripheral, string dataServiceUUID)
        {
            this.Peripheral = peripheral;
            this.Name = peripheral.Name;
            this.dataServiceUUID = dataServiceUUID;
        }

        public string Name { get; set; }
        public CBPeripheral Peripheral { get; internal set; }
        public string UUID { get; set; }

    }
}