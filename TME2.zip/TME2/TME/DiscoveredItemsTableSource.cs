using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace TME
{
    public class DiscoveredItemsTableSource : UITableViewSource
    {
        public List<DiscoverItem> TableItems { get; set; }
        string CellIdentifier = "TableCell";
        private FirstViewController firstViewController;

        public DiscoveredItemsTableSource()
        {
            TableItems = new List<DiscoverItem>();
        }

        public DiscoveredItemsTableSource(FirstViewController firstViewController) : this()
        {
            this.firstViewController = firstViewController;
        }

        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            var uuid = TableItems[indexPath.Row].Peripheral;
           // firstViewController.Connect(uuid);
        }

        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return TableItems.Count;
        }

        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            UITableViewCell cell = tableView.DequeueReusableCell(CellIdentifier);
            string item = TableItems[indexPath.Row].Name;

            //---- if there are no cells to reuse, create a new one
            if (cell == null)
            { cell = new UITableViewCell(UITableViewCellStyle.Default, CellIdentifier); }

            cell.TextLabel.Text = item;

            return cell;
        }
    }

}